<?php

namespace App\Http\Controllers;

use App\Models\Industry;
use App\Models\Language;
use App\Models\Region;

class RegionLanguageController extends Controller
{
    public function index(Region $region, Language $language)
    {
        // All industries with their active categories (crawlable link hub).
        $industries = Industry::active()
            ->ordered()
            ->with(['categories' => fn ($q) => $q->active()->ordered()])
            ->get();

        return view('region-language', [
            'industries' => $industries,
        ]);
    }
}
