<?php

namespace App\Http\Controllers;

use App\Models\Language;
use App\Models\Region;

class HomeController extends Controller
{
    public function index()
    {
        $regions   = Region::active()->ordered()->get();
        $languages = Language::active()->ordered()->get();

        return view('home', [
            'regions'   => $regions,
            'languages' => $languages,
        ]);
    }
}
