@extends('layouts.app')

@section('title', __('messages.site_name') . ' — ' . __('messages.tagline'))
@section('meta_description', __('messages.tagline'))

@section('content')
    <section class="hero">
        <h1>{{ __('messages.site_name') }}</h1>
        <p class="lead">{{ __('messages.tagline') }}</p>
    </section>

    {{-- Regions: each region links to every available language (crawlable hub) --}}
    <section class="home-section">
        <h2>{{ __('messages.all_regions') }}</h2>
        <div class="region-grid">
            @foreach ($regions as $region)
                <div class="region-card">
                    <h3>{{ $region->translate('name') }}</h3>
                    <ul class="lang-links">
                        @foreach ($languages as $language)
                            <li>
                                <a href="{{ route('region.home', [$region, $language]) }}">
                                    {{ $language->native_name ?? $language->name }}
                                </a>
                            </li>
                        @endforeach
                    </ul>
                </div>
            @endforeach
        </div>
    </section>

    {{-- Languages: link each language into the first region as an entry point --}}
    <section class="home-section">
        <h2>{{ __('messages.all_languages') }}</h2>
        <ul class="language-list">
            @foreach ($languages as $language)
                <li>
                    <a href="{{ route('region.home', [$regions->first(), $language]) }}">
                        {{ $language->native_name ?? $language->name }}
                        <small>({{ strtoupper($language->code) }})</small>
                    </a>
                </li>
            @endforeach
        </ul>
    </section>
@endsection
