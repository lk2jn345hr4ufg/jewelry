@extends('layouts.app')

@php($regionName = $currentRegion->translate('name'))

@section('title', __('messages.site_name') . ' · ' . $regionName)
@section('meta_description', __('messages.tagline') . ' — ' . $regionName)

@section('content')
    <section class="hero hero-compact">
        <h1>{{ __('messages.site_name') }} · {{ $regionName }}</h1>
        <p class="lead">{{ __('messages.tagline') }}</p>
        @include('partials.quick-search')
    </section>

    <section class="home-section">
        <h2>{{ __('messages.all_industries') }}</h2>

        <div class="industry-grid">
            @foreach ($industries as $industry)
                <div class="industry-block">
                    <h3>
                        <a href="{{ route('industry.show', [$currentRegion, $currentLanguage, $industry]) }}">
                            {{ $industry->translate('name') }}
                        </a>
                    </h3>
                    <ul class="category-links">
                        @foreach ($industry->categories as $category)
                            <li>
                                <a href="{{ route('category.show', [$currentRegion, $currentLanguage, $industry, $category]) }}">
                                    {{ $category->translate('name') }}
                                </a>
                            </li>
                        @endforeach
                    </ul>
                </div>
            @endforeach
        </div>
    </section>
@endsection
