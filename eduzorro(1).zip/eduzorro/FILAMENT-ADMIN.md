# Eduzorro admin panel (Filament)

Adds a full admin panel at `/admin` for managing regions, languages, industries,
categories, companies, and — most importantly — the review moderation queue.

## What's included

| Resource   | What you can do                                                          |
|------------|---------------------------------------------------------------------------|
| Regions    | CRUD, drag-to-reorder, translatable name, parent/child hierarchy         |
| Languages  | CRUD, drag-to-reorder, direction (ltr/rtl)                               |
| Industries | CRUD, translatable name/description                                      |
| Categories | CRUD, translatable name/description, industry picker                    |
| Companies  | CRUD, category + multi-region picker, translatable description, verified/active toggles |
| Reviews    | **Moderation queue** — approve/unapprove per row or in bulk, sidebar badge showing pending count, filter by approval status |

The dashboard also shows a small stats overview (active companies, active
regions, pending reviews).

Translatable fields (`name`, `description`) render as a tab per active
language — no translation package involved, it's just the existing JSON
columns addressed with dot-notation field names (`name.en`, `name.es`, …),
which Laravel's array cast handles natively.

## Install

Run these from your project root (`~/Herd/eduzorro` if you're using Herd):

```bash
# 1. Install Filament's panel builder (v3, which added Laravel 13 support)
composer require filament/filament:"^3.0-stable" -W

# 2. Scaffold the panel — creates app/Providers/Filament/AdminPanelProvider.php
#    and registers it in bootstrap/providers.php
php artisan filament:install --panels
#   When prompted for a panel ID, accept the default: admin
#   When asked to create a user, you can skip it — the seeder makes one (see below)
```

Then overlay this package's files (same as any other update — see the main
README/setup guide for the full `cp -R` sequence). This adds/replaces:

```
app/Filament/...                     (all resources, widgets, the TranslatableTabs helper)
app/Providers/Filament/AdminPanelProvider.php   (replaces the generated one — same class/path)
app/Models/User.php                  (adds the FilamentUser contract)
database/seeders/DatabaseSeeder.php  (adds a default admin user)
```

> If you'd already customized `app/Models/User.php`, diff it against ours
> first — we only added the `FilamentUser` interface and a `canAccessPanel()`
> method; everything else is stock Laravel.

Finally, migrate/seed and clear caches:

```bash
php artisan migrate:fresh --seed
php artisan optimize:clear
```

## Log in

```
URL:      http://localhost:8000/admin   (or https://eduzorro.test/admin on Herd)
Email:    [email protected]
Password: password
```

**Change that password before deploying anywhere public.**

## Access control

`User::canAccessPanel()` currently returns `true` for anyone with an account —
fine for local development, not fine for production. Before deploying, tighten
it, e.g.:

```php
public function canAccessPanel(Panel $panel): bool
{
    return str_ends_with($this->email, '@yourdomain.com');
}
```

or add an `is_admin` boolean column and check that instead.

## Notes

- Digital companies are auto-attached to every active region on save (in
  addition to whatever you pick manually in the Regions field), matching the
  public site's rule that digital companies appear everywhere.
- The Reviews sidebar badge counts unapproved reviews — it's the fastest way
  to see if anything needs moderating.
- Adding a new language in **Languages** automatically adds a new tab to every
  translatable field across Regions/Industries/Categories/Companies — no code
  changes needed.
